# Import libraries
from flask import Flask,request, render_template
import pickle

app = Flask(__name__)

# Load the model
model = pickle.load(open('model.pkl','rb'))

@app.route('/')
def index():
    return render_template('2index.html')

@app.route('/',methods=['POST','GET'])
def prediction():
    # reading input year
    year = request.form['year']
    if year == "" :
        return render_template('2result.html', fish ='not available,', 
        cake ="\nPlease enter 'zero' if you are a fresher!!!")
    year = float(year)
    if year == 0:
        salary= model.predict([[float(year)]])
        salary = int(salary)
        return render_template('2result.html', rs = "Rs.",value=salary, cat ='\n You are a fresher')
    # calling salary predict function
    salary= model.predict([[float(year)]])
    salary = int(salary)
    return render_template('2result.html',rs = "Rs.", value=salary)
    
if __name__ == '__main__':
    app.run(debug=True)
